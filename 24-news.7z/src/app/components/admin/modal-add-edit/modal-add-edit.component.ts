import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-add-edit',
  templateUrl: './modal-add-edit.component.html',
  styleUrls: ['./modal-add-edit.component.scss']
})
export class ModalAddEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
