export interface Category {
  id?: string | number;
  color: string;
  bgColor: string;
  nameUA: string;
  nameEN: string;
}
