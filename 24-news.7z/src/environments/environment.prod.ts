export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyAvI-w9SRWUREsIOU45n9LPVCfpLTdMAqY',
    authDomain: 'auth-task-d4f75.firebaseapp.com',
    databaseURL: 'https://auth-task-d4f75.firebaseio.com',
    projectId: 'auth-task-d4f75',
    storageBucket: 'auth-task-d4f75.appspot.com',
    messagingSenderId: '3348067675',
    appId: '1:3348067675:web:03eb8a2a34d1501687167e',
    measurementId: 'G-7KMD1LVJ1S'
  }
};
